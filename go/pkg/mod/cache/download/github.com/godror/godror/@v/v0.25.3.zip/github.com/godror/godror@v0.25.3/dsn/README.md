For connection string formats, see [../doc/connection.md](../doc/connection.md).
