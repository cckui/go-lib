package persist

import (
	"testing"
)

func TestPersist(t *testing.T) {
	//No tests yet
}
