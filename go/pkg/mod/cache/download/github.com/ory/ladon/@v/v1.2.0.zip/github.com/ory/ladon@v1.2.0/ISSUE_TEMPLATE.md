Please use issues only to raise potential bugs or request features. For everything else ask
the [ORY Community](https://community.ory.am/) or join the [ORY Chat](https://gitter.im/ory-am/hydra).

If you think you found a security vulnerability, please refrain from posting it publicly on the forums, the chat, or GitHub
and send us an email to [hi@ory.am](mailto:hi@ory.am) instead.
